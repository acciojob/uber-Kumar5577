package com.driver.model;

public enum TripStatus {
    CONFIRMED,CANCELED,COMPLETED
}
